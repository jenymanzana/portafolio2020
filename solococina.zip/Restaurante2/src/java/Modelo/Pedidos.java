
package Modelo;
import java.util.Date;

public class Pedidos {
    
    private int Id_pedido;
    private String Codigo_pedido;
    private Date Fecha_pedido;
    private int Id_mesa;

    public Pedidos(int Id_pedido, String Codigo_pedido, Date Fecha_pedido, int Id_mesa) {
        this.Id_pedido = Id_pedido;
        this.Codigo_pedido = Codigo_pedido;
        this.Fecha_pedido = Fecha_pedido;
        this.Id_mesa = Id_mesa;
    }

    public int getId_pedido() {
        return Id_pedido;
    }

    public void setId_pedido(int Id_pedido) {
        this.Id_pedido = Id_pedido;
    }

    public String getCodigo_pedido() {
        return Codigo_pedido;
    }

    public void setCodigo_pedido(String Codigo_pedido) {
        this.Codigo_pedido = Codigo_pedido;
    }

    public Date getFecha_pedido() {
        return Fecha_pedido;
    }

    public void setFecha_pedido(Date Fecha_pedido) {
        this.Fecha_pedido = Fecha_pedido;
    }

    public int getId_mesa() {
        return Id_mesa;
    }

    public void setId_mesa(int Id_mesa) {
        this.Id_mesa = Id_mesa;
    }
    
    
    
}
