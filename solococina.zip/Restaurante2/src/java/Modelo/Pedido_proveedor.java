
package Modelo;
import java.util.Date;

public class Pedido_proveedor {
    
    private int Id_pedido;
    private int Total_pedido;
    private Date Fecha_pedido;
    private Date Hora_pedido;
    private String Descripcion_pedido;
    private int Id_proveedor;
    private String Id_empleado;

    public Pedido_proveedor(int Id_pedido, int Total_pedido, Date Fecha_pedido, Date Hora_pedido, String Descripcion_pedido, int Id_proveedor, String Id_empleado) {
        this.Id_pedido = Id_pedido;
        this.Total_pedido = Total_pedido;
        this.Fecha_pedido = Fecha_pedido;
        this.Hora_pedido = Hora_pedido;
        this.Descripcion_pedido = Descripcion_pedido;
        this.Id_proveedor = Id_proveedor;
        this.Id_empleado = Id_empleado;
    }

    public int getId_pedido() {
        return Id_pedido;
    }

    public void setId_pedido(int Id_pedido) {
        this.Id_pedido = Id_pedido;
    }

    public int getTotal_pedido() {
        return Total_pedido;
    }

    public void setTotal_pedido(int Total_pedido) {
        this.Total_pedido = Total_pedido;
    }

    public Date getFecha_pedido() {
        return Fecha_pedido;
    }

    public void setFecha_pedido(Date Fecha_pedido) {
        this.Fecha_pedido = Fecha_pedido;
    }

    public Date getHora_pedido() {
        return Hora_pedido;
    }

    public void setHora_pedido(Date Hora_pedido) {
        this.Hora_pedido = Hora_pedido;
    }

    public String getDescripcion_pedido() {
        return Descripcion_pedido;
    }

    public void setDescripcion_pedido(String Descripcion_pedido) {
        this.Descripcion_pedido = Descripcion_pedido;
    }

    public int getId_proveedor() {
        return Id_proveedor;
    }

    public void setId_proveedor(int Id_proveedor) {
        this.Id_proveedor = Id_proveedor;
    }

    public String getId_empleado() {
        return Id_empleado;
    }

    public void setId_empleado(String Id_empleado) {
        this.Id_empleado = Id_empleado;
    }

    
}
