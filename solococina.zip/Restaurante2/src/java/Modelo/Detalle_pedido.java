
package Modelo;
import java.util.Date;

public class Detalle_pedido {
    
    private int cantidad_pedido;
    private Date Fecha_pedido;
    private int Id_Pedidos;
    private int Id_Mesa;
    private int Id_Menu;

    public Detalle_pedido(int cantidad_pedido, Date Fecha_pedido, int Id_Pedidos, int Id_Mesa, int Id_Menu) {
        this.cantidad_pedido = cantidad_pedido;
        this.Fecha_pedido = Fecha_pedido;
        this.Id_Pedidos = Id_Pedidos;
        this.Id_Mesa = Id_Mesa;
        this.Id_Menu = Id_Menu;
    }

    public int getCantidad_pedido() {
        return cantidad_pedido;
    }

    public void setCantidad_pedido(int cantidad_pedido) {
        this.cantidad_pedido = cantidad_pedido;
    }

    public Date getFecha_pedido() {
        return Fecha_pedido;
    }

    public void setFecha_pedido(Date Fecha_pedido) {
        this.Fecha_pedido = Fecha_pedido;
    }

    public int getId_Pedidos() {
        return Id_Pedidos;
    }

    public void setId_Pedidos(int Id_Pedidos) {
        this.Id_Pedidos = Id_Pedidos;
    }

    public int getId_Mesa() {
        return Id_Mesa;
    }

    public void setId_Mesa(int Id_Mesa) {
        this.Id_Mesa = Id_Mesa;
    }

    public int getId_Menu() {
        return Id_Menu;
    }

    public void setId_Menu(int Id_Menu) {
        this.Id_Menu = Id_Menu;
    }
    
    

    
    
}
