/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author chicv
 */
public class Detalle_solicitud {
    
    
    private int Cantidad_solicitud;
    private int Id_pedido_prov;
    private int Id_proveedor;
    private String Id_Empleado;
    private int Id_Insumo;

    public Detalle_solicitud( int Cantidad_solicitud, int Id_pedido_prov, int Id_proveedor, String Id_Empleado, int Id_Insumo) {
       
        this.Cantidad_solicitud = Cantidad_solicitud;
        this.Id_pedido_prov = Id_pedido_prov;
        this.Id_proveedor = Id_proveedor;
        this.Id_Empleado = Id_Empleado;
        this.Id_Insumo = Id_Insumo;
    }

  

    public int getCantidad_solicitud() {
        return Cantidad_solicitud;
    }

    public void setCantidad_solicitud(int Cantidad_solicitud) {
        this.Cantidad_solicitud = Cantidad_solicitud;
    }

    public int getId_pedido_prov() {
        return Id_pedido_prov;
    }

    public void setId_pedido_prov(int Id_pedido_prov) {
        this.Id_pedido_prov = Id_pedido_prov;
    }

    public int getId_proveedor() {
        return Id_proveedor;
    }

    public void setId_proveedor(int Id_proveedor) {
        this.Id_proveedor = Id_proveedor;
    }

    public String getId_Empleado() {
        return Id_Empleado;
    }

    public void setId_Empleado(String Id_Empleado) {
        this.Id_Empleado = Id_Empleado;
    }

    public int getId_Insumo() {
        return Id_Insumo;
    }

    public void setId_Insumo(int Id_Insumo) {
        this.Id_Insumo = Id_Insumo;
    }
    
    
}
