
function calcularTotal(){
    var totalneto, totalcnprop;
    totalneto=document.getElementById("totalneto").value;
    alert("El valor neto es: "+totalneto);
}